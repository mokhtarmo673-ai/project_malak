<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 shadow-sm">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">WE Student Portal</a>
      <div class="navbar-nav">
        <a class="nav-link" href="student.php">Student Check</a>
        <a class="nav-link fw-bold text-warning" href="index.php">Dashboard(Admin)</a>
      </div>
    </div>
  </nav>
<script src="bootstrap.bundle.min.js"></script>
</body>
</html>