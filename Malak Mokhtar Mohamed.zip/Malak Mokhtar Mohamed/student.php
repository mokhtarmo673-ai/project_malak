<?php
$con =mysqli_connect("localhost" ,  "root" , "" , "school_db");
if(!$con){die("Database Connection Failed");}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Portal - Check Result</title>
</head>
<body>
    <?php include 'navbar.php' ?>
    <!-- Form -->
    <div class="container">
        <div class="row justify-content-centar">
            <div class="col-md-6">
                <div class="card shadow-sn p-4 md-4 border-0">
                    <h3 class="text-primary md-3 text-center">Find Your Result</h3>
                    <form method="POST" action="student.php">
                        <div class="md3">
                            <label class="form-label fw-bold">Enter Your Name</label>
                            <input type="text" name="search_name" class="form-control form-control-lg" placeholder="e.g.Ahmed" required> 
                        </div>
                        <button type="submit" class="btn btn-primary w-100 btn-lg mt-3">Search</button>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $search_name = trim($_POST['search_name']);
        $search_sql = "SELECT * FROM students WHERE name LIKE'%$search_name%'";
        $result = mysqli_query($con, $search_sql);
        if (mysqli_num_rows($result) > 0) {
            while ($student = mysqli_fetch_assoc($result)) {
                $score = $student['score'];
                $isPass = $score >= 50;
                $statusText = $isPass ? "Pass" : "Fail";
                $badgeClass = $isPass ? "alert-success" : "alert-danger";
                ?>
                <div class="card shadow p-4 text-center border-0 mb-4">
                    <h4 class="text-secondary">Official Result Card</h4>
                    <hr>
                    <h2 class="text-dark mb-3"><?= htmlspecialchars($student['name'])?></h2>
                    <h3 class="mb-4">Score: <strong><?= $score ?></strong> /100</h3>
                    <div class="alert <?= $badgeClass ?> fw-bold fs-4 mb-0">
                        Status: <?= $statusText ?>
                    </div>
                </div>
                <?php
                }
                } else {
                    echo "<div class='alert alert-warning text-center fw-bold fs-5 shadow-sm'>
                    No student found matching '" . htmlspecialchars($search_name) ."'.</div>";
                    }
                    }
                    ?>
                    </div>
                </div>
            </div>
            <?php
            $conn = mysqli_connect("localhost", "root", "", "school_db");
            if (!$conn) { die("Database Connection Failed!"); }
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $name = $_POST['$student_name'];
                $score = $_POST['$student_score'];
                if (!empty($name) && is_numeric($score)) {
                    mysqli_query($conn, "INSERT INTO students (name, score) VALUES('$name', $score)");
                    header("Location: index.php");
                    exit();
                    }
                    }
                    ?>
                    </body>
                    </html>